
$("#filter").click( function (e){
    e.preventDefault();
    $("#mobile-filter").toggleClass("menuDisplayed");

});